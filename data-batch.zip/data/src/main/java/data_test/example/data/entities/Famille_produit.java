package data_test.example.data.entities;

import jakarta.persistence.*;
import lombok.Data;
import jakarta.persistence.Id;

import java.util.List;

@Entity
@Table(name = "dim_famille_produit")
@Data
public class Famille_produit {
    @Id
    private long id_famille_produit;

    @OneToMany(mappedBy = "famille_produit", cascade = CascadeType.ALL)
    private List<Recouvrement> recouvrements;


    public void setId(long id) {
        this.id_famille_produit = id;
    }
    public long getId() {
        return id_famille_produit;
    }

}
