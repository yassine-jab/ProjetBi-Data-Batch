package data_test.example.data.rowmap;

import data_test.example.data.entities.Segment;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SegmentRowMap implements RowMapper<Segment> {

    @Override
    public Segment mapRow(ResultSet rs, int rowNum) throws SQLException {
        Segment table1Entity = new Segment();
        table1Entity.setId(rs.getLong("id"));
        table1Entity.setNomSegment(rs.getString("nom_segment"));
        table1Entity.setDescription(rs.getString("description"));
        return table1Entity;
    }
}
