package data_test.example.data.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Data;
import java.util.List;
import jakarta.persistence.Id;

@Entity
@Data
@Table(name = "dim_personne")
public class Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_personne", nullable = false, updatable = false)
    private Long idPersonne; // Nom de la variable changé pour correspondre aux conventions Java

    @Size(max = 255)
    @Column(name = "type_personne")
    private String type_personne;


    // Relation One-to-Many avec Recouvrement
    @OneToMany(mappedBy = "personne", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Recouvrement> recouvrements;

    public void setId(long id) {
        this.idPersonne = id;
    }
    public long getId() {
        return idPersonne;
    }
    public void setType_personne(String type_personne) {
        this.type_personne = type_personne;
    }
    public String getType_personne() {
        return type_personne;
    }
}
