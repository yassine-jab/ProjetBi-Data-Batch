package data_test.example.data.Data_Plat;

import data_test.example.data.entities.Segment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SegmentRepository extends JpaRepository<Segment, Long> {
}
