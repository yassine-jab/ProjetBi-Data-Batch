package data_test.example.data.entities;
import jakarta.persistence.Id;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;
@Entity
@Data
@Table(name = "dim_calendrier")
public class Calendrier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_date", nullable = false)
    private long Id_date;
    private LocalDate date;

    private int semestre;
    private int trimestre;
    private String mois;
    private String libelle_mois;
    private int annee;
    private String jour;
    @OneToMany(mappedBy = "calendrier")
    private List<Recouvrement> recouvrements;

    public void setId(long id) {
        this.Id_date = id;
    }

    public long getId_date() {
        return Id_date;
    }
    public void setId_date(long id_date) {
        this.Id_date = id_date;
    }
    public LocalDate getDate() {
        return date;
    }
    public void setDate(LocalDate date) {
        this.date = date;
    }
    public int getSemestre() {
        return semestre;
    }
    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }
    public int getTrimestre() {
        return trimestre;
    }
    public void setTrimestre(int trimestre) {
        this.trimestre = trimestre;
    }
    public String getMois() {
        return mois;
    }
    public void setMois(String mois) {
        this.mois = mois;
    }
    public String getLibelle_mois() {
        return libelle_mois;
    }
    public void setLibelle_mois(String libelle_mois) {
        this.libelle_mois = libelle_mois;
    }
    public int getAnnee() {
        return annee;
    }
    public void setAnnee(int annee) {
        this.annee = annee;
    }
    public String getJour() {
        return jour;
    }
    public void setJour(String jour) {
        this.jour = jour;
    }
}
