package data_test.example.data.entities;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "dim_agence")
public class Agence {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_agence", nullable = false)
    private Long idAgence;
    @Size(max = 255)
    @Column(name = "nom_agence")
    private String nomAgence;
    @Size(max = 255)
    @Column(name = "adresse")
    private String adresse;

    @Size(max = 255)
    @Column(name = "directeur_agence")
    private String directeurAgence;
    private LocalDate dateCreation;

    @OneToMany(mappedBy = "agence")
    private List<Recouvrement> recouvrement;


    // Getters et setters
    public Long getId() { return idAgence; }
    public void setId(Long id) { this.idAgence = id; }

    public String getNom() { return nomAgence; }
    public void setName(String nom) { this.nomAgence = nom; }

    public String getAdresse() { return adresse; }
    public void setAddress(String adresse) { this.adresse = adresse; }
}

