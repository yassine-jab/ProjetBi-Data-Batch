package data_test.example.data.entities;



import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Data;
import jakarta.persistence.Id;
import java.util.List;

@Entity
@Data
@Table(name = "dim_agent")
public class Agent{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_agent", nullable = false)
    private int idAgent;
    @Size(max = 255)
    @Column(name = "poste_occupe")
    private String poste;
    @Size(max = 255)
    @Column(name = "departement")
    private String departement;
    @Size(max = 255)
    @Column(name = "statut_emploi")
    private String statutEmploi;
    @Size(max = 255)
    @Column(name = "superieur_hierarchique")
    private String superieurHierarchique;


    @OneToMany(mappedBy = "agent")
    private List<Recouvrement> recouvrements;
    public void setPoste(String poste) {this.poste = poste;}
    public void setDepartement(String departement) {this.departement = departement;}
    public void setStatutEmploi(String statutEmploi) { this.statutEmploi = statutEmploi;}
    public int getId () {return this.idAgent;}
    public void setId(int idAgent) {this.idAgent = idAgent;}
}
