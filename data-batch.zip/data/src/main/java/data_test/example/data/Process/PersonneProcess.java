package data_test.example.data.Process;
import data_test.example.data.entities.Personne;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

public class PersonneProcess implements ItemProcessor<Personne, Personne> {

    private static final Logger log = LoggerFactory.getLogger(PersonneProcess.class); // Use SLF4J logger

    @Override
    public Personne process(final Personne personne) throws Exception {
        // Simple transformation: Convert 'type_personne' to uppercase
        String typePersonne = personne.getType_personne();

        if (typePersonne != null) {
            personne.setType_personne(typePersonne.toUpperCase());
        }

        // Log the processed item
        log.info("Processing Personne with ID: {}, Type: {}", personne.getIdPersonne(), personne.getType_personne());

        // Return the transformed person object
        return personne;
    }
}
