package data_test.example.data.rowmap;

import data_test.example.data.entities.Calendrier;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CalendrierRowMapper implements RowMapper<Calendrier> {

    @Override
    public Calendrier mapRow(ResultSet rs, int rowNum) throws SQLException {
        Calendrier table1Entity = new Calendrier();
        table1Entity.setId(rs.getLong("id"));
        table1Entity.setDate(rs.getDate("date").toLocalDate());
        table1Entity.setSemestre(rs.getInt("semestre"));
        table1Entity.setTrimestre(rs.getInt("trimestre"));
        table1Entity.setMois(rs.getString("mois"));
        table1Entity.setLibelle_mois(rs.getString("libelle_mois"));
        table1Entity.setAnnee(rs.getInt("annee"));
        table1Entity.setJour(rs.getString("jour"));
        table1Entity.setId(rs.getLong("id"));
        return table1Entity;
    }
}