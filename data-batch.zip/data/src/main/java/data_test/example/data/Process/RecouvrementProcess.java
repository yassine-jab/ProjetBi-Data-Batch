package data_test.example.data.Process;

import data_test.example.data.entities.Recouvrement;
import org.springframework.batch.item.ItemProcessor;

public class RecouvrementProcess implements ItemProcessor<Recouvrement, Recouvrement> {

    @Override
    public Recouvrement process(Recouvrement recouvrement) throws Exception {

        if (recouvrement.getAgence() == null || recouvrement.getAgent() == null ||
                recouvrement.getPersonne() == null || recouvrement.getSegment() == null)
         {
            return null;
        }

        long montantTotal = recouvrement.getMontantEcheance() + recouvrement.getMontantFinance();
        recouvrement.setSolde(montantTotal - recouvrement.getSolde());

        return recouvrement;
    }
}
