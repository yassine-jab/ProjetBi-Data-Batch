package data_test.example.data.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.Id;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "dim_segment")

public class Segment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_segment", nullable = false)
    private long idSegment;

    @Column(name = "nom_segment")
    private String nomSegment;

    private String description;


    @OneToMany(mappedBy = "segment")
    private List<Recouvrement> recouvrements;

    public void setId(long id) {
        this.idSegment = id;
    }
    public void setNomSegment(String nomSegment) {
        this.nomSegment = nomSegment;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public long getIdSegment() {
        return idSegment;
    }
    public String getNomSegment() {
        return nomSegment;
    }
    public String getDescription() {
        return description;
    }

}
