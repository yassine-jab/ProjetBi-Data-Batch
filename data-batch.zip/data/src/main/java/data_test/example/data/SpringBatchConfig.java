package data_test.example.data;
import data_test.example.data.Process.*;
import data_test.example.data.entities.*;
import data_test.example.data.rowmap.*;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.support.DataFieldMaxValueIncrementerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import javax.sql.DataSource;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Import(DataSourceConfig.class)
public class SpringBatchConfig {
@Autowired
    private   JobRepository jobRepository;



    private  DataSource dataSource;

    @Autowired
    public SpringBatchConfig(JobRepository jobRepository, DataSource dataSource) {
        this.jobRepository = jobRepository;
        this.dataSource = dataSource;
    }
    @Bean
    public Step step1(JdbcCursorItemReader<Agence> AgenceItemReader, JdbcBatchItemWriter<Agence> AgenceItemWriter) {
        return new StepBuilder("step-load-data 1", jobRepository)
                .<Agence, Agence>chunk(10, dataSourceTransactionManager())
                .reader(AgenceItemReader)
                .processor( AgenceProcessor())
                .writer(AgenceItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Agence> agenceRowMapper() {
        return new AgenceRowMapper();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Agence> AgenceItemReader() {
        JdbcCursorItemReader<Agence> reader = new JdbcCursorItemReader<>();
        reader.setSql("SELECT * FROM dim_agence");
        reader.setRowMapper(agenceRowMapper());
        reader.setDataSource(dataSource);
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Agence> AgenceItemWriter() {
        JdbcBatchItemWriter<Agence> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO dim_agence (id, name, address) VALUES (:id, :name, :address)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
@Bean
    public ItemProcessor<Agence, Agence> AgenceProcessor() {
        return new AgenceProcess();
    }

    @Bean
    public Step step2(JdbcCursorItemReader<Agent> AgentItemReader, JdbcBatchItemWriter<Agent> AgentItemWriter) {
        return  new StepBuilder("step-load-data 2", jobRepository)
                .<Agent, Agent>chunk(10, dataSourceTransactionManager())
                .reader(AgentItemReader)
                .processor( agentItemProcessor())
                .writer(AgentItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Agent> agentRowMapper() {
        return new AgentRowMapper();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Agent> AgentItemReader() {
        JdbcCursorItemReader<Agent> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_agent");
        reader.setRowMapper(agentRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Agent> AgentItemWriter() {
        JdbcBatchItemWriter<Agent> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
@Bean
public ItemProcessor<Agent, Agent> agentItemProcessor() {
    return new AgentProcess();
}

    @Bean
    public Step step3(JdbcCursorItemReader<Calendrier> CalendrierItemReader, JdbcBatchItemWriter<Calendrier> CalendrierItemWriter) {
        return new StepBuilder("step-load-data 3", jobRepository)
                .<Calendrier, Calendrier>chunk(10, dataSourceTransactionManager())
                .reader(CalendrierItemReader)
                .processor( calendrierItemProcessor())
                .writer(CalendrierItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Calendrier> calendrierRowMapper() {
        return new CalendrierRowMapper();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Calendrier> CalendrierItemReader() {
        JdbcCursorItemReader<Calendrier> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_calendrier");
        reader.setRowMapper(calendrierRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Calendrier> CalendrierItemWriter() {
        JdbcBatchItemWriter<Calendrier> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Calendrier, Calendrier> calendrierItemProcessor() {
        return new CalendrierPROCESS();
    }
    @Bean
    public Step step4(JdbcCursorItemReader<Dossier> DossierItemReader, JdbcBatchItemWriter<Dossier> DossierItemWriter) {
        return new StepBuilder("step-load-data 4",jobRepository)
                .<Dossier, Dossier>chunk(10, dataSourceTransactionManager())
                .reader(DossierItemReader)
                .processor( dossierierItemProcessor())
                .writer(DossierItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Dossier> dossierRowMapper() {

        return new DossierRowMapper();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Dossier> DossierItemReader() {
        JdbcCursorItemReader<Dossier> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_dossier");
        reader.setRowMapper(dossierRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Dossier> DossierItemWriter() {
        JdbcBatchItemWriter<Dossier> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Dossier, Dossier> dossierierItemProcessor() {
        return new DossierProcess();
    }

    @Bean
    public Step step5(JdbcCursorItemReader<Famille_produit> Famille_produitItemReader, JdbcBatchItemWriter<Famille_produit> Famille_produitItemWriter) {
        return new StepBuilder("step-load-data 5", jobRepository)
                .<Famille_produit, Famille_produit>chunk(10, dataSourceTransactionManager())
                .reader(Famille_produitItemReader)
                .processor( famille_produitProcessor())
                .writer(Famille_produitItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Famille_produit> famille_produitRowMapper() {
        return new FamilleProduitRowMapper();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Famille_produit> Famille_produitItemReader() {
        JdbcCursorItemReader<Famille_produit> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_famille_produit");
        reader.setRowMapper(famille_produitRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Famille_produit> Famille_produitItemWriter() {
        JdbcBatchItemWriter<Famille_produit> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Famille_produit, Famille_produit>   famille_produitProcessor() {
        return new Famille_ProduitProcess();
    }

    @Bean
    public Step step6(JdbcCursorItemReader<Personne>PersonneItemReader, JdbcBatchItemWriter<Personne> PersonneItemWriter) {
        return new StepBuilder("step-load-data 6", jobRepository)
                .<Personne, Personne>chunk(10, dataSourceTransactionManager())
                .reader(PersonneItemReader)
                .processor( personneItemProcessor())
                .writer(PersonneItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Personne> personneRowMapper() {
        return new PersonneRowMap();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Personne> PersonneItemReader() {
        JdbcCursorItemReader<Personne> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_personne");
        reader.setRowMapper(personneRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Personne> PersonneItemWriter() {
        JdbcBatchItemWriter<Personne> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Personne, Personne> personneItemProcessor() {
        return new PersonneProcess();
    }
    @Bean
    public Step step7(JdbcCursorItemReader<Recouvrement> RecouvrementItemReader, JdbcBatchItemWriter<Recouvrement> RecouvrementItemWriter) {
        return new StepBuilder("step-load-data 7", jobRepository)
                .<Recouvrement, Recouvrement>chunk(10, dataSourceTransactionManager())
                .reader(RecouvrementItemReader)
                .processor( recouvrementProcessor())
                .writer(RecouvrementItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Recouvrement> recouvrementRowMapper() {
        return new RecouvrementRowMap();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Recouvrement> recouvrementItemReader() {
        JdbcCursorItemReader<Recouvrement> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM fait_recouvrement");
        reader.setRowMapper(recouvrementRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Recouvrement> recouvrementItemWriter() {
        JdbcBatchItemWriter<Recouvrement> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Recouvrement, Recouvrement>  recouvrementProcessor() {

        return new RecouvrementProcess();
    }

    @Bean
    public Step step8(JdbcCursorItemReader<Segment> SegmentItemReader, JdbcBatchItemWriter<Segment> SegmentItemWriter) {
        return new StepBuilder("step-load-data 8", jobRepository)
                .<Segment, Segment>chunk(10, dataSourceTransactionManager())
                .reader(SegmentItemReader)
                .processor(segmentProcessor())
                .writer(SegmentItemWriter)
                .build();
    }
    @Bean
    public RowMapper<Segment> segmentRowMapper() {
        return new SegmentRowMap();
    }
    @Bean
    @StepScope
    public JdbcCursorItemReader<Segment> SegmentItemReader() {
        JdbcCursorItemReader<Segment> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT * FROM dim_segment");
        reader.setRowMapper(segmentRowMapper());
        return reader;
    }
    @Bean
    @StepScope
    public JdbcBatchItemWriter<Segment> SegmentItemWriter() {
        JdbcBatchItemWriter<Segment> writer = new JdbcBatchItemWriter<>();
        writer.setDataSource(dataSource);
        writer.setSql("INSERT INTO gestion_rec (id) VALUES (:id)");
        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
        return writer;
    }
    @Bean
    public ItemProcessor<Segment, Segment>  segmentProcessor() {

        return new SegmentProcess();
    }


@Bean
    public Job jobBuilder(Step step1,Step step2,Step step3,Step step4,Step step5,Step step6,Step step7,Step step8) {
        return new JobBuilder("readTablesJob",jobRepository)
                .start(step1)
                .next(step2)
                .next(step3)
                .next(step4)
                .next(step5)
                .next(step6)
                .next(step7)
                .next(step8)
                .build();
    }

    @Bean
    public PlatformTransactionManager dataSourceTransactionManager() {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public JpaTransactionManager jpaTransactionManager(EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }

}
