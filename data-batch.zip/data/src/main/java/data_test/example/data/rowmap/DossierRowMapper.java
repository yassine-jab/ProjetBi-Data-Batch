package data_test.example.data.rowmap;


import data_test.example.data.entities.*;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DossierRowMapper implements RowMapper<Dossier> {

    @Override
    public Dossier mapRow(ResultSet rs, int rowNum) throws SQLException {
        Dossier table1Entity = new Dossier();
        table1Entity.setId(rs.getLong("id"));
        return table1Entity;
    }
}
