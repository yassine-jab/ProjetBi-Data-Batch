package data_test.example.data.Process;

import data_test.example.data.entities.Agent;
import org.springframework.batch.item.ItemProcessor;

public class AgentProcess implements ItemProcessor<Agent, Agent> {

    @Override
    public Agent process(Agent agent) throws Exception {


        if (agent.getPoste() == null || agent.getPoste().isEmpty()) {
            return null; // Ignorer cet agent si le poste est manquant
        }

        if (agent.getDepartement() == null || agent.getDepartement().isEmpty()) {
            return null;
        }

        agent.setPoste(agent.getPoste().toUpperCase());

        if (agent.getSuperieurHierarchique() == null || agent.getSuperieurHierarchique().isEmpty()) {
            agent.setSuperieurHierarchique("Non spécifié");
        }

        return agent;
    }
}
