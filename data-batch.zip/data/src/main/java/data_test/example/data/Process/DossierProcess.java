package data_test.example.data.Process;

import data_test.example.data.entities.Dossier;
import org.springframework.batch.item.ItemProcessor;


public class DossierProcess implements ItemProcessor<Dossier, Dossier> {

    @Override
    public Dossier process(Dossier dossier) throws Exception {
            return dossier;
        }
}
