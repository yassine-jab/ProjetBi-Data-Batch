package data_test.example.data.Process;

import data_test.example.data.entities.Famille_produit;
import org.springframework.batch.item.ItemProcessor;

import java.util.Collections;

public class Famille_ProduitProcess implements ItemProcessor<Famille_produit, Famille_produit> {

    @Override
    public Famille_produit process(Famille_produit familleProduit) throws Exception {


            if (familleProduit.getId_famille_produit() <= 0) {
                return null;
            }
            if (familleProduit.getRecouvrements() == null) {
                familleProduit.setRecouvrements(Collections.emptyList());
            }
            return familleProduit;
        }
}
