package data_test.example.data.Data_Plat;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Gestion_Rec {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long idSegment;

    private Long idRecouvrement;

    private Long idCalendrier;

    private Long idAgence;

    private Long idAgent;

    private Long idPersonne;

    private Long idDossier;

    private Long idFamilleProduit;
}

