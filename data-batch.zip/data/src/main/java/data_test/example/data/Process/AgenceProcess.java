package data_test.example.data.Process;

import data_test.example.data.entities.Agence;

import org.springframework.batch.item.ItemProcessor;

public class AgenceProcess implements ItemProcessor<Agence, Agence> {

    @Override
    public Agence process(Agence  agence) throws Exception {

        if (agence.getNomAgence() == null || agence.getNomAgence().isEmpty()) {
            return null;
        }
        if (agence.getDirecteurAgence() == null || agence.getDirecteurAgence().isEmpty()) {
            agence.setDirecteurAgence("Directeur inconnu");
        }
        return agence;
    }
}

