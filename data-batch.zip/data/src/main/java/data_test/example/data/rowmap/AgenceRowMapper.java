package data_test.example.data.rowmap;
import data_test.example.data.entities.Agence;
import org.jetbrains.annotations.NotNull;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AgenceRowMapper implements RowMapper<Agence> {

    @Override
    public Agence mapRow(ResultSet rs, int rowNum) throws SQLException {
        Agence agence = new Agence();
        agence.setId(rs.getLong("id"));
        agence.setName(rs.getString("name"));
        agence.setAddress(rs.getString("address"));
        return agence;
    }
}

