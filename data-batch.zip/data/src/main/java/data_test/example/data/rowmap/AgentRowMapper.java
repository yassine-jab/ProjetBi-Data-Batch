package data_test.example.data.rowmap;

import data_test.example.data.entities.Agent;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AgentRowMapper implements RowMapper<Agent> {

    @Override
    public Agent mapRow(ResultSet rs, int rowNum) throws SQLException {
        Agent table1Entity = new Agent();
        table1Entity.setId(rs.getInt("idAgent"));
        table1Entity.setPoste(rs.getString("poste"));
        table1Entity.setDepartement(rs.getString("departement"));
        table1Entity.setStatutEmploi(rs.getString("statut_emploi"));
        table1Entity.setSuperieurHierarchique(rs.getString("superieur_hierarchique"));

        return table1Entity;
    }
}