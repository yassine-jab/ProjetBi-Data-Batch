package data_test.example.data.Process;

import data_test.example.data.Data_Plat.Gestion_Rec;
import data_test.example.data.entities.Recouvrement;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class GestionRecProcessor implements ItemProcessor<Recouvrement, Gestion_Rec> {

    @Override
    public Gestion_Rec process(Recouvrement recouvrement) throws Exception {
        Gestion_Rec gestionRec = new Gestion_Rec();

        // Assigner les IDs des entités liées à l'objet GestionRec
        gestionRec.setIdSegment(recouvrement.getId_dim_segment());
        gestionRec.setIdRecouvrement(recouvrement.getId_fact());
        gestionRec.setIdCalendrier(recouvrement.getId_date_prem_impaye()); // Ex: idCalendrier
        gestionRec.setIdAgence(recouvrement.getId_dim_agence());
        gestionRec.setIdAgent(recouvrement.getId_agent());
        gestionRec.setIdPersonne(recouvrement.getDim_personne());
        gestionRec.setIdDossier(recouvrement.getId_dim_dossier());
        gestionRec.setIdFamilleProduit(recouvrement.getId_dimfamille_produit());

        return gestionRec;
    }
}
