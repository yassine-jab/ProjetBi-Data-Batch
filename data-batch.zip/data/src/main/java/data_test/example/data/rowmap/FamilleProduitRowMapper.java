package data_test.example.data.rowmap;

import data_test.example.data.entities.Famille_produit;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FamilleProduitRowMapper implements RowMapper<Famille_produit> {

    @Override
    public Famille_produit mapRow(ResultSet rs, int rowNum) throws SQLException {
        Famille_produit table1Entity = new Famille_produit();
        table1Entity.setId(rs.getLong("id"));
        return table1Entity;
    }
}