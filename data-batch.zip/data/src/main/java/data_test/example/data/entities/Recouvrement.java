package data_test.example.data.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.Id;

@Getter
@Setter
@Entity
@Table(name = "fait_recouvrement")
public class Recouvrement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idFact; // Clé primaire

    private long montantEcheance;
    private long montantFinance;
    private long solde;
    private int nombreDossier;

    // Relation avec Personne
    @ManyToOne
    @JoinColumn(name = "id_dim_personne", nullable = false)
    private Personne personne;

    // Relation avec Agence
    @ManyToOne
    @JoinColumn(name = "id_dim_agence", nullable = false)
    private Agence agence;

    // Relation avec Segment
    @ManyToOne
    @JoinColumn(name = "id_dim_segment", nullable = false)
    private Segment segment;
    @ManyToOne
    private Calendrier calendrier;
    // Relation avec Agent
    @ManyToOne
    @JoinColumn(name = "id_dim_agent", nullable = false)
    private Agent agent;

    // Relation avec FamilleProduit
    @ManyToOne
    @JoinColumn(name = "id_dim_famille_produit")
    private Famille_produit famille_produit;

    // Relation avec Dossier
    @ManyToOne
    @JoinColumn(name = "id_dim_dossier", nullable = false)
    private Dossier dossier;

    // Date de premier impayé (si nécessaire, ajoutez un mapping approprié)
    private long datePremierImpaye;

    public void setId(long id) {
        this.idFact = id;
    }


    public long getId_dim_segment() {
        return segment.getIdSegment();
    }

    public Long getId_fact() {
        return idFact;
    }

    public Long getId_date_prem_impaye() {
        return datePremierImpaye;
    }

    public long getId_dim_agence() {
        return agence.getIdAgence();
    }

    public long getId_agent() {
        return agent.getIdAgent();
    }

    public long getDim_personne() {
        return personne.getIdPersonne();
    }

    public long getId_dim_dossier() {
        return dossier.getIdDossier();
    }

    public long getId_dimfamille_produit() {
        return this.idFact;
    }

    public long getId() {
        return this.idFact;
    }


    public void setMontantEcheance(long montantEcheance) {
        this.montantEcheance = montantEcheance;
    }
    public void setMontantFinance(long montantFinance) {
        this.montantFinance = montantFinance;
    }
    public void setSolde(long solde) {
        this.solde = solde;
    }
    public void setNombreDossier(int nombreDossier) {
        this.nombreDossier = nombreDossier;
    }
    public void setPersonne(Personne personne) {
        this.personne = personne;
    }
    public void setAgence(Agence agence) {
        this.agence = agence;
    }
    public void setSegment(Segment segment) {
        this.segment = segment;
    }
    public void setAgent(Agent agent) {
        this.agent = agent;
    }
}

