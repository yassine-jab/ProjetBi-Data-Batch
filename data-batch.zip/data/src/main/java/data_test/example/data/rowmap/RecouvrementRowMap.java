package data_test.example.data.rowmap;

import data_test.example.data.entities.Recouvrement;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RecouvrementRowMap implements RowMapper<Recouvrement> {

    @Override
    public Recouvrement mapRow(ResultSet rs, int rowNum) throws SQLException {
        Recouvrement table1Entity = new Recouvrement();
        table1Entity.setId(rs.getLong("id"));
        table1Entity.setMontantEcheance(rs.getLong("montant_echeance"));
        table1Entity.setMontantFinance(rs.getLong("montant_finance"));
        table1Entity.setSolde(rs.getLong("solde"));
        table1Entity.setNombreDossier(rs.getInt("nombre_dossier"));
        table1Entity.setDatePremierImpaye(rs.getLong("date_premier_impaye"));
        return table1Entity;
    }
}
