package data_test.example.data.entities;

import jakarta.persistence.*;
import lombok.*;
import jakarta.persistence.Id;

import java.util.List;

@Getter
@Setter
@Entity
@AllArgsConstructor @NoArgsConstructor
@Table(name = "dim_dossier")
public class Dossier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_dossier")
    private Long idDossier;
    @OneToMany(mappedBy = "dossier")
    private List<Recouvrement> recouvrements;

    public void setId(long id) {
        this.idDossier = id;
    }
public long getIdDossier(){return idDossier;}
}

