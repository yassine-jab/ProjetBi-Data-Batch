package data_test.example.data.Process;

import data_test.example.data.entities.Segment;
import org.springframework.batch.item.ItemProcessor;

public class SegmentProcess implements ItemProcessor<Segment, Segment> {

    @Override
    public Segment process(Segment segment) throws Exception {


        if (segment.getNomSegment() == null || segment.getNomSegment().isEmpty()) {
            return null;
        }
        if (segment.getDescription() != null && segment.getDescription().length() > 255) {
            return null;
        }
        return segment;
    }
}

