package data_test.example.data.rowmap;

import data_test.example.data.entities.Personne;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PersonneRowMap implements RowMapper<Personne> {

    @Override
    public Personne mapRow(ResultSet rs, int rowNum) throws SQLException {
        Personne table1Entity = new Personne();
        table1Entity.setId(rs.getLong("id"));
        table1Entity.setType_personne(rs.getString("type"));
        return table1Entity;
    }
}
