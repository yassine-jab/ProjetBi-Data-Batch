package data_test.example.data.Process;

import data_test.example.data.entities.Calendrier;
import org.springframework.batch.item.ItemProcessor;

public class CalendrierPROCESS implements ItemProcessor<Calendrier, Calendrier> {

    @Override
    public Calendrier process(Calendrier calendrier) throws Exception {


        if (calendrier.getDate() == null) {
            return null;
        }

        if (calendrier.getAnnee() < 1900 || calendrier.getAnnee() > 2100) {
            return null;
        }

        if (calendrier.getMois() != null) {
            calendrier.setMois(calendrier.getMois().toUpperCase());
        }

        if (calendrier.getLibelle_mois() == null && calendrier.getMois() != null) {
            calendrier.setLibelle_mois("Libellé de " + calendrier.getMois());
        }

        if (calendrier.getTrimestre() < 1 || calendrier.getTrimestre() > 4) {
            return null;}

        if (calendrier.getSemestre() < 1 || calendrier.getSemestre() > 2) {
            return null;
        }

        return calendrier;
    }
}
