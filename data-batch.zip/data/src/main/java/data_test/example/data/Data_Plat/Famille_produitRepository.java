package data_test.example.data.Data_Plat;

import data_test.example.data.entities.Famille_produit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Famille_produitRepository extends JpaRepository<Famille_produit, Long> {
}
