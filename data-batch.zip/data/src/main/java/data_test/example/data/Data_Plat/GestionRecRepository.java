package data_test.example.data.Data_Plat;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GestionRecRepository extends JpaRepository<Gestion_Rec, Long> {
}
